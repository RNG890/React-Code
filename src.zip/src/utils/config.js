//TODO: DONE add firebase configuration and export it
export const firebaseConfig = {
  apiKey: "AIzaSyDBfb9s-MBlKurranNRpt4guJxGGJFmngw",
  authDomain: "mygitapp-86dfa.firebaseapp.com",
  databaseURL: "https://mygitapp-86dfa.firebaseio.com",
  projectId: "mygitapp-86dfa",
  storageBucket: "mygitapp-86dfa.appspot.com",
  messagingSenderId: "377974217237",
  appId: "1:377974217237:web:2fa39baffb02300df60c1c",
  measurementId: "G-P7NQDYNNKY"
};
//image configuration
export const imageConfig = {
  quality: 0.2,
  maxWidth: 800,
  maxHeight: 600,
  autoRotate: true
};
